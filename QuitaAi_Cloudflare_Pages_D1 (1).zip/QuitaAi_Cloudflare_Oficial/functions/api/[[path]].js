const headers={'content-type':'application/json; charset=utf-8','cache-control':'no-store','x-content-type-options':'nosniff'};
const reply=(data,status=200,extra={})=>new Response(JSON.stringify(data),{status,headers:{...headers,...extra}});
const bytes=s=>new TextEncoder().encode(s);
const hex=buf=>Array.from(new Uint8Array(buf)).map(b=>b.toString(16).padStart(2,'0')).join('');
const hash=async s=>hex(await crypto.subtle.digest('SHA-256',bytes(s)));
const pbkdf=async(p,s)=>{const k=await crypto.subtle.importKey('raw',bytes(p),'PBKDF2',false,['deriveBits']);return hex(await crypto.subtle.deriveBits({name:'PBKDF2',salt:bytes(s),iterations:210000,hash:'SHA-256'},k,256));};
const id=()=>crypto.randomUUID();
const cookie=(r)=>r.headers.get('cookie')?.match(/(?:^|; )qa_session=([^;]+)/)?.[1]||'';
const cleanUser=u=>u&&({id:u.id,name:u.name,role:u.role});
async function who(db,r){const token=cookie(r);if(!token)return null;return db.prepare('SELECT u.id,u.name,u.role FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>datetime(\'now\')').bind(await hash(token)).first();}
async function log(db,u,action,target){await db.prepare('INSERT INTO audit(id,actor_id,action,target_id) VALUES(?,?,?,?)').bind(id(),u,action,target||null).run();}
async function data(r){if(Number(r.headers.get('content-length')||0)>16000)throw Error('Dados muito grandes');return await r.json();}
export async function onRequest({request:r,env}){
 const db=env.DB;if(!db)return reply({error:'Banco D1 não configurado. Crie a vinculação DB no Cloudflare.'},503);
 const url=new URL(r.url),path=url.pathname.replace(/^\/api\/?/,'');const method=r.method;
 if(!['GET','POST'].includes(method))return reply({error:'Método não permitido'},405);
 if(method==='POST'&&r.headers.get('origin')!==url.origin)return reply({error:'Origem não autorizada'},403);
 try{
 const u=await who(db,r);
 if(path==='me'&&method==='GET')return reply({user:cleanUser(u)});
 if(path==='register'&&method==='POST'){
  const b=await data(r),name=String(b.name||'').trim(),email=String(b.email||'').trim().toLowerCase(),pass=String(b.password||''),role=b.role;
  if(name.length<3||name.length>100||!/^\S+@\S+\.\S+$/.test(email)||email.length>180||pass.length<12||pass.length>128||!['donor','recipient'].includes(role)||b.accepted!==true)return reply({error:'Preencha os campos, use senha de 12 caracteres e aceite os termos.'},400);
  const salt=id(),uid=id();try{await db.batch([db.prepare('INSERT INTO users(id,name,email,pass_hash,role,accepted_at) VALUES(?,?,?,?,?,CURRENT_TIMESTAMP)').bind(uid,name,email,`${salt}:${await pbkdf(pass,salt)}`,role),db.prepare('INSERT INTO wallets(user_id,balance) VALUES(?,0)').bind(uid)]);}catch{return reply({error:'Não foi possível cadastrar. Verifique se o e-mail já está em uso.'},409)}
  return reply({ok:true},201);
 }
 if(path==='login'&&method==='POST'){
  const b=await data(r),email=String(b.email||'').trim().toLowerCase(),pass=String(b.password||'');if(email.length>180||pass.length>128)return reply({error:'Dados inválidos'},400);
  const a=await db.prepare('SELECT count,window_start FROM attempts WHERE email=?').bind(email).first();if(a&&a.count>=5&&Date.now()-Date.parse(a.window_start+'Z')<15*60000)return reply({error:'Muitas tentativas. Aguarde 15 minutos.'},429);
  const found=await db.prepare('SELECT * FROM users WHERE email=?').bind(email).first();let valid=false;
  if(found){const [salt,digest]=found.pass_hash.split(':');valid=(await pbkdf(pass,salt))===digest;}else await pbkdf(pass,'00000000-0000-0000-0000-000000000000');
  if(!valid){await db.prepare("INSERT INTO attempts(email,count,window_start) VALUES(?,1,datetime('now')) ON CONFLICT(email) DO UPDATE SET count=CASE WHEN window_start<datetime('now','-15 minutes') THEN 1 ELSE count+1 END,window_start=CASE WHEN window_start<datetime('now','-15 minutes') THEN datetime('now') ELSE window_start END").bind(email).run();return reply({error:'E-mail ou senha incorretos'},401);}
  await db.prepare('DELETE FROM attempts WHERE email=?').bind(email).run();const token=id()+id();await db.prepare("INSERT INTO sessions(token_hash,user_id,expires_at) VALUES(?,?,datetime('now','+7 days'))").bind(await hash(token),found.id).run();return reply({user:cleanUser(found)},200,{'set-cookie':`qa_session=${token}; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=604800`});
 }
 if(path==='logout'&&method==='POST'){if(cookie(r))await db.prepare('DELETE FROM sessions WHERE token_hash=?').bind(await hash(cookie(r))).run();return reply({ok:true},200,{'set-cookie':'qa_session=; HttpOnly; Secure; SameSite=Strict; Path=/; Max-Age=0'});}
 if(path==='bills'&&method==='GET'){
  const rows=await db.prepare("SELECT b.id,b.category,b.amount,b.reason,b.status,b.created_at,CASE WHEN b.status='approved' THEN substr(u.name,1,1)||'***' ELSE NULL END AS requester FROM bills b JOIN users u ON u.id=b.user_id WHERE b.status='approved' ORDER BY b.created_at DESC LIMIT 100").all();return reply({bills:rows.results});
 }
 if(!u)return reply({error:'Faça login para continuar'},401);
 if(path==='mine'&&method==='GET'){
  const bills=await db.prepare('SELECT id,category,amount,reason,status,created_at FROM bills WHERE user_id=? ORDER BY created_at DESC').bind(u.id).all();const reservations=await db.prepare("SELECT id,category,amount,reason,status FROM bills WHERE donor_id=? ORDER BY created_at DESC").bind(u.id).all();const wallet=await db.prepare('SELECT balance FROM wallets WHERE user_id=?').bind(u.id).first();return reply({bills:bills.results,reservations:reservations.results,balance:wallet?.balance||0});
 }
 if(path==='create'&&method==='POST'){
  if(u.role!=='recipient')return reply({error:'Somente solicitantes'},403);const b=await data(r),amount=Math.round(Number(b.amount)*100),category=String(b.category||''),reason=String(b.reason||'').trim();
  if(!['Energia','Água','Gás','Moradia','Outra conta essencial'].includes(category)||!Number.isSafeInteger(amount)||amount<=100000||amount>10000000||reason.length<25||reason.length>1000)return reply({error:'Preencha uma conta acima de R$ 1.000,00 e uma justificativa de 25 a 1000 caracteres.'},400);
  const active=await db.prepare("SELECT id FROM bills WHERE user_id=? AND status IN ('pending','approved','reserved','awaiting') LIMIT 1").bind(u.id).first();if(active)return reply({error:'Você já tem uma solicitação ativa.'},409);
  const bid=id();await db.prepare('INSERT INTO bills(id,user_id,category,amount,reason) VALUES(?,?,?,?,?)').bind(bid,u.id,category,amount,reason).run();await log(db,u.id,'pedido_criado',bid);return reply({ok:true},201);
 }
 if(path==='admin'&&method==='GET'){
  if(u.role!=='admin')return reply({error:'Acesso restrito'},403);const bills=await db.prepare("SELECT b.id,b.category,b.amount,b.reason,b.status,u.name AS requester FROM bills b JOIN users u ON u.id=b.user_id WHERE b.status IN ('pending','awaiting') ORDER BY b.created_at DESC").all();return reply({bills:bills.results});
 }
 if(path==='review'&&method==='POST'){
  if(u.role!=='admin')return reply({error:'Acesso restrito'},403);const b=await data(r);if(!['approved','rejected','paid'].includes(b.action))return reply({error:'Ação inválida'},400);
  const old=b.action==='paid'?'awaiting':'pending';const result=await db.prepare('UPDATE bills SET status=? WHERE id=? AND status=?').bind(b.action,String(b.id),old).run();if(!result.meta.changes)return reply({error:'Pedido indisponível ou já alterado'},409);
  if(b.action==='paid')await db.prepare("UPDATE payments SET status='confirmed' WHERE bill_id=? AND status='pending'").bind(String(b.id)).run();await log(db,u.id,'revisao_'+b.action,String(b.id));return reply({ok:true});
 }
 if(path==='reserve'&&method==='POST'){
  if(u.role!=='donor')return reply({error:'Somente doadores'},403);const b=await data(r);const result=await db.prepare("UPDATE bills SET status='reserved',donor_id=? WHERE id=? AND status='approved'").bind(u.id,String(b.id)).run();if(!result.meta.changes)return reply({error:'Pedido não está mais disponível'},409);await log(db,u.id,'reserva',String(b.id));return reply({ok:true});
 }
 if(path==='credit'&&method==='POST'){
  if(u.role!=='donor')return reply({error:'Somente doadores'},403);const b=await data(r),c=Math.round(Number(b.amount)*100);if(!Number.isSafeInteger(c)||c<100||c>1000000)return reply({error:'Use um valor fictício entre R$ 1 e R$ 10.000.'},400);await db.prepare('UPDATE wallets SET balance=balance+? WHERE user_id=?').bind(c,u.id).run();await log(db,u.id,'credito_ficticio',String(c));return reply({ok:true});
 }
 if(path==='pay'&&method==='POST'){
  if(u.role!=='donor')return reply({error:'Somente doadores'},403);const b=await data(r);const bill=await db.prepare("SELECT id,amount FROM bills WHERE id=? AND donor_id=? AND status='reserved'").bind(String(b.id),u.id).first();if(!bill)return reply({error:'Reserva não encontrada'},409);const total=bill.amount+99;
  try{await db.batch([db.prepare('UPDATE wallets SET balance=balance-? WHERE user_id=? AND balance>=?').bind(total,u.id,total),db.prepare("INSERT INTO payments(bill_id,donor_id,total) SELECT id,?,? FROM bills WHERE id=? AND donor_id=? AND status='reserved' AND (SELECT balance FROM wallets WHERE user_id=?)>=0 AND changes()=1").bind(u.id,total,bill.id,u.id,u.id),db.prepare("UPDATE bills SET status='awaiting' WHERE id=? AND status='reserved' AND EXISTS(SELECT 1 FROM payments WHERE bill_id=?)").bind(bill.id,bill.id)]);}catch{return reply({error:'Saldo insuficiente ou pagamento já processado.'},409)}
  const paid=await db.prepare('SELECT bill_id FROM payments WHERE bill_id=?').bind(bill.id).first();if(!paid)return reply({error:'Saldo insuficiente.'},409);await log(db,u.id,'pagamento_ficticio',bill.id);return reply({ok:true});
 }
 return reply({error:'Rota não encontrada'},404);
 }catch(e){return reply({error:'Não foi possível concluir a operação. Tente novamente.'},500)}
}
