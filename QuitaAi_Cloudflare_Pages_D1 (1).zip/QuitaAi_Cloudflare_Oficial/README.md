# QuitaAí — Cloudflare Pages + D1

Aplicação funcional **para demonstração educacional**. Não processa dinheiro, não armazena documentos nem dados bancários. Não é uma plataforma financeira aprovada para operação comercial.

## Publicação via GitHub

1. Crie um repositório **privado** no GitHub e envie os arquivos desta pasta, preservando `functions/`, `public/` e `database/`.
2. Cloudflare > Workers & Pages > Create > Pages > Connect to Git > escolha o repositório.
3. Framework: None; build command: deixe vazio; output directory: `public`.
4. Cloudflare > D1 > Create database > nome sugerido `quitaai-db`.
5. No D1, abra Console e execute o conteúdo de `database/schema.sql`. Para produção, prefira usar Wrangler: `npx wrangler d1 execute quitaai-db --remote --file=database/schema.sql` (após autenticar e confirmar o banco correto).
6. Pages > projeto > Settings > Bindings > Add > D1 database. **Variable name: `DB`**, escolha `quitaai-db`. Salve e **redeploy**.
7. Abra o endereço `*.pages.dev` fornecido no painel. Teste cadastro, login, solicitação, aprovação, reserva e pagamento fictício.

## Criar administrador de testes

Não existe cadastro público de administrador. Crie uma conta normalmente e depois, no Console do banco D1, execute com seu e-mail de teste:

```sql
UPDATE users SET role='admin' WHERE email='SEU-EMAIL-DE-TESTE@EXEMPLO.COM';
```

Saia e entre novamente. Não use esse procedimento em uma base com usuários reais sem um processo administrativo seguro.

## Limitações importantes

- **Não publicar como serviço financeiro real.** Todos os pagamentos e créditos são fictícios.
- A versão Cloudflare foi **reescrita** para JavaScript/Pages Functions/D1; não migra automaticamente usuários e dados do MySQL anterior.
- O aceite dos termos é registrado com data, mas requer revisão jurídica, política de retenção, bases legais e contato real.
- Não há recuperação de senha, confirmação de e-mail, canal automatizado de direitos LGPD, proteção anti-bot, testes de penetração, monitoramento, auditoria independente ou política operacional de backup.
- O fluxo de pagamento simulado precisa de testes de concorrência em produção e reforço de transações antes de qualquer operação financeira.
- O painel de administração é acessível somente ao papel `admin` no servidor. Não há conta admin padrão.
- A criação de pedidos não aceita comprovantes nem renda; esses recursos foram removidos para reduzir riscos de privacidade.
- Não há integração com gateway de pagamento. A taxa de R$0,99 é apenas parte da simulação.
- Os campos **[PREENCHER...]** em Termos e Política devem ser substituídos por informações reais antes de uma publicação pública.

## Checklist pré-lançamento público

- [ ] Preencher identificação e contato do controlador e suporte
- [ ] Revisar textos legais e bases legais com profissional habilitado
- [ ] Implementar e testar solicitação de exclusão, acesso e correção
- [ ] Criar plano de retenção, backup, recuperação e incidentes
- [ ] Verificar fluxo completo e testes de concorrência/segurança
- [ ] Adicionar verificação de e-mail e recuperação segura de conta
- [ ] Configurar monitoramento e proteção anti-abuso
- [ ] Remover dados de teste e verificar configurações de acesso
- [ ] Definir se a operação envolve pagamentos reais; se sim, contratar parceiro regulado e obter análise jurídica/regulatória específica
